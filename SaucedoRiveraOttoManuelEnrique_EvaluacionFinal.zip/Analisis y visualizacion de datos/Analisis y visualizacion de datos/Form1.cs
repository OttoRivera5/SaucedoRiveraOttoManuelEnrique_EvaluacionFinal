﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Analisis_y_visualizacion_de_datos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
       
          
            // Crear una instancia del gráfico
            Chart chart = chart1;

            // Agregar los datos de la tabla de gastos trimestrales
            int[,] gastosTrimestrales = {
        { 20 },
        { 35 },
        { 12 },
        { 45 },
        { 28 },
        

    };

            // Limpiar el gráfico (por si ya tiene datos)
            this.chart1.Series.Clear();

            // Configurar el estilo del gráfico
            this.chart1.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            this.chart1.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            this.chart1.ChartAreas[0].AxisX.Title = "CATEGORIA";
            this.chart1.ChartAreas[0].AxisY.Title = "VALOR";

            string[] categorias = { "CATEGORIA1", "CATEGORIA2", "CATEGORIA3", "CATEGORIA4", "CATEGORIA5" };

            // Crear una serie para cada fila de la tabla
            for (int i = 0; i < gastosTrimestrales.GetLength(0); i++)
            {
                Series series = new Series();
                series.ChartType = SeriesChartType.Bar;
                series.Name = categorias[i];


                // Agregar los datos de cada trimestre a la serie
                for (int j = 0; j < gastosTrimestrales.GetLength(1); j++)
                {
                    series.Points.AddXY("T" + (j + 1), gastosTrimestrales[i, j]);
                }

                // Agregar la serie al gráfico
                this.chart1.Series.Add(series);



                // Crear la tabla de datos
                DataTable table = new DataTable();

                // Agregar las columnas a la tabla
                table.Columns.Add("CATEGORIA", typeof(string));
                table.Columns.Add("VALOR", typeof(string));

                

                // Agregar las filas a la tabla con los datos de gastos trimestrales
                table.Rows.Add("CATEGORIA1", 20 );
                table.Rows.Add("CATEGORIA2", 35);
                table.Rows.Add("CATEGORIA3", 12 );
                table.Rows.Add("CATEGORIA4", 45 );
                table.Rows.Add("CATEGORIA5", 28);
                



                // Crear el control DataGridView
                DataGridView dataGridView = new DataGridView();
                dataGridView.Dock = DockStyle.Fill;
                dataGridView.AutoGenerateColumns = true;
                dataGridView.DataSource = table;

                // Agregar el control DataGridView al formulario
                Controls.Add(dataGridView);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
                  
        }
    }
}
